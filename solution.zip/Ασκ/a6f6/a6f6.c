#include <stdio.h>
#include "genlib.h"
#include "simpio.h"

#define N 5

void readData(float a[N][4]);
void FindMean(int deikths, float a[N][4], float mo[]);

int main()
{
    float a[N][4], mo[N];
    readData(a);


    FindMean(1, a, mo);
    printf("Mesos oros barous andrwn: %.1f\n", mo[0]);
    printf("Mesos oros barous gynaikwn: %.1f\n", mo[1]);
    printf("\n");

    FindMean(2, a, mo);
    printf("Mesos oros ypsous andrwn: %.1f\n", mo[0]);
    printf("Mesos oros ypsous gynaikwn: %.1f\n", mo[1]);
    printf("\n");

    FindMean(3, a, mo);
    printf("Mesos oros hlikias andrwn: %.1f\n", mo[0]);
    printf("Mesos oros hlikias gynaikwn: %.1f\n", mo[1]);
    printf("\n");

    return 0;
}

void readData(float a[N][4])
{
    int i, j;

    for (i=0;i<N;i++)
    {
        printf("Dwse fylo: ");
        a[i][0] = GetReal();
        printf("Dwse baros: ");
        a[i][1] = GetReal();
        printf("Dwse ypsos: ");
        a[i][2] = GetReal();
        printf("Dwse ilikia: ");
        a[i][3] = GetReal();
        printf("-----\n");
    }
}

void FindMean(int deikths, float a[N][4], float mo[])
{

    int i, m, w;
    float sm, sw;
    m=0;
    w=0;
    sm=0;
    sw=0;
    for (i=0;i<N;i++)
    {
        if (a[i][0] == 0)
        {
            sm += a[i][deikths];
            m++;
        }
        else
        {
            sw += a[i][deikths];
            w++;
        }
        if (m != 0)
           {mo[0] = sm / m;}
        if (w != 0)
            {mo[1] = sw / w;}
    }
}

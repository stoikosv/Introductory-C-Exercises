#include <stdio.h>
#include "genlib.h"
#include "simpio.h"

int menu();
double metatroph(int ep, double poso);

int main()
{
    int ep;
    double poso;

    ep = menu();
    while (ep != 6)
    {
        printf("Dwse poso: ");
        poso = GetReal();

        printf("To poso einai: %.2f\n",metatroph(ep,poso));
        ep = menu();
    }

    return 0;
}

int menu()
{
    int ep;

    printf("1.Metatroph se dolaria\n2.Metatroph se lires\n3.Metatroph se fraga Elbetias\n4.Metatroph se dollaria canadas\n5.Metatroph se gien\n6.Exodos\n");
    printf("Dwse epilogh: ");
    ep = GetInteger();

    return ep;
}

double metatroph(int ep, double poso)
{

    double result;


    if (ep == 1)
    {
        result = poso / 0.89;
    }
    else if (ep == 2)
     {
        result = poso / 0.618;
     }
    else if (ep == 3)
      {
        result = poso / 1.5465;
      }
    else if (ep == 4)
       {
        result = poso / 1.3565;
       }
    else if (ep == 5)
        {
        result = poso / 109.22;
        }
    return result;
}


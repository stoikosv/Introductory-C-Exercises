#include <stdio.h>
#include "genlib.h"
#include "stdio.h"
#include <string.h>

char DateString(int day, int month, int year, char date[10]);

int main()
{
    int hmera, mhnas, etos;
    char date[10];

    printf("Dwse thn hmera: ");
    hmera = GetInteger();
    printf("Dwse ton mhna: ");
    mhnas = GetInteger();
    printf("Dwse to etos: ");
    etos = GetInteger();

    DateString(hmera, mhnas, etos, date);
    printf("%s ", date);

    return 0;
}

char DateString(int day, int month, int year, char date[10])
{
    char* month_name;
    switch (month) {
        case 1: month_name = "Jan"; break;
        case 2: month_name = "Feb"; break;
        case 3: month_name = "Mar"; break;
        case 4: month_name = "Apr"; break;
        case 5: month_name = "May"; break;
        case 6: month_name = "Jun"; break;
        case 7: month_name = "Jul"; break;
        case 8: month_name = "Aug"; break;
        case 9: month_name = "Sep"; break;
        case 10: month_name = "Oct"; break;
        case 11: month_name = "Nov"; break;
        case 12: month_name = "Dec"; break;
        default: month_name = ""; break;
    }
    sprintf(date, "%d-%s-%02d", day, month_name, year % 100);
}


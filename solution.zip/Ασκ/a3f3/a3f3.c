#include <stdio.h>
#include "genlib.h"
#include "simpio.h"

int main()
{
    long kibwtia_es, kibwtia_ex, poso_es, poso_ex, poso, poso_apostolis;

    poso_es = 0;
    poso_ex = 0;
    poso = 0;
    poso_apostolis = 0;

    printf("Kibwtia eswterikou? ");
    kibwtia_es = GetLong();

    while(kibwtia_es >= 0)
    {
        printf("Kibwtia exwterikou? ");
        kibwtia_ex = GetLong();
        kibwtia_es = kibwtia_es * 10;
        kibwtia_ex = kibwtia_ex * 15;
        poso = kibwtia_es +kibwtia_ex;
        poso_es = poso_es + kibwtia_es;
        poso_ex = poso_ex + kibwtia_ex;
        poso_apostolis = poso_apostolis + poso;
        printf("%10ld%10ld%10ld\n", kibwtia_es, kibwtia_ex, poso);
        printf("Kibwtia eswterikou? ");
        kibwtia_es = GetLong();
    }

    printf("%10ld%10ld%10ld\n", poso_es, poso_ex, poso_apostolis);

    return 0;
}

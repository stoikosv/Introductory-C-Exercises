#include <stdio.h>
#include "genlib.h"
#include "simpio.h"

void decompose(long x, long *digits, double *mo, long *max);

int main()
{
    double mo;
    long x, max, digits;

    printf("Please insert non-negative number: ");
    x = GetLong();

    decompose(x, &digits, &mo, &max);
    printf("Digits: %ld\n", digits);
    printf("Average: %.3f\n", mo);
    printf("Max: %ld\n", max);

    return 0;
}

void decompose(long x, long *digits, double *mo, long *max)
{
    long d = 0, mx = 0;
    double MO = 0;

    while (x != 0)
    {
        long a = x%10;
        d++;
        MO += (double)a;
        if (a>mx)
        {
            mx = a;
        }
        x/=10;
    }
    MO /= d !=0? (double) d : 1.0;
    *digits =d;
    *max = mx;
    *mo = MO;
}

#include <stdio.h>
#include "genlib.h"
#include "simpio.h"

int main()
{
    int i, N, div;
    float sum;

    printf("Dwse orio: ");
    N = GetInteger();

    sum = 0;
    div = 1;

    for( i=1; i<=N; i++ )
    {
        sum += 1 / (double)div;
        div = div +1;
    }

    printf("To athroisma einai %.2f\n", sum);

    return 0;
}

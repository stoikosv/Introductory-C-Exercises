#include <stdio.h>
#include "genlib.h"
#include "simpio.h"
#include "math.h"

int main()
{
    int est_time, real_time, dif;

    printf("Dwse problepomeno xrono: ");
    est_time = GetInteger();
    printf("Dwse pragmatiko xrono: ");
    real_time = GetInteger();

    if (est_time <= 29)
        dif = 1;
    else if (est_time < 59)
        dif = 2;
    else if (est_time <= 89)
        dif = 3;
    else if (est_time <= 119)
        dif = 4;
    else if (est_time <= 179)
        dif = 6;
    else if (est_time <= 239)
        dif = 8;
    else if (est_time <= 359)
        dif = 13;
    else if (est_time >= 360)
        dif = 17;

    printf("Apodekth diafora: %d\n", dif);
    printf("Diafora eisodou: %d\n", (est_time - real_time));

    if (abs(est_time - real_time) <= dif)
    {
        printf("GOOD\n");
    }
    else
    {
        if (est_time > real_time)
        {
            printf("BIG\n");
        }
        else if (est_time < real_time)
        {
            printf("SMALL\n");
        }
    }

    return 0;
}

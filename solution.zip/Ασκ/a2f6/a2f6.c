#include <stdio.h>
#include "genlib.h"
#include "stdio.h"

#define N 100

int readData(int a[]);
void findMinMax(int size, int a[], int *pmax, int *pmin);

int main()
{
    int a[N];
    int size, pmax, pmin;
    size = readData(a);
    findMinMax(size, a, &pmax, &pmin);
    printf("The range of values is %d-%d", pmin, pmax);
    return 0;
}

int readData(int a[])
{
    int size;
    size = 0;
    printf("Enter the elements of the array, one per line.\nUse -1 to signal the end of the list.\n");
    printf("? ");
    a[size] = GetInteger();
    while (a[size] != -1)
    {
        size++;
        printf("? ");
        a[size] = GetInteger();

    }
    return size;
}

void findMinMax(int size, int a[], int *pmax, int *pmin)
{
    int i, max, min;
    max = a[0];
    min = a[0];
    for (i=0;i<size;i++)
    {
        if (a[i] > max)
            max = a[i];
        if (a[i] < min)
            min = a[i];
    }
    *pmax = max;
    *pmin = min;
}

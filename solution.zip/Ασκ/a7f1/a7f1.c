/*File: a7f1.c
 *This program calculates
 *the VAT that the company
 *must bimonthly
 */

 #include <stdio.h>
 #include "genlib.h"
 #include "simpio.h"


 main() {
  long fpa4, fpa8, fpa18;
  double sumfpa;

  printf("Dwse tis synolikes eispraxeis gia FPA 0.04: ");
  fpa4 = GetLong();
  printf("Dwse tis synolikes eispraxeis gia FPA 0.08: ");
  fpa8 = GetLong();
  printf("Dwse tis synolikes eispraxeis gia FPA 0.18: ");
  fpa18 = GetLong();

  sumfpa = fpa4 * 0.4 + fpa8 * 0.08 + fpa18 * 0.18;

  printf("To synoliko poso FPA einai %g\n", sumfpa);

 }

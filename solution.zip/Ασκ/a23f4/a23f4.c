#include <stdio.h>
#include "genlib.h"
#include "simpio.h"

bool Valid_Time(int hours, int min, int sec);

int main()
{
    int hours, min, sec;

    printf("Dwse tis ores: ");
    hours = GetInteger();
    printf("Dwse ta lepta: ");
    min = GetInteger();
    printf("Dwse ta defterolepta: ");
    sec = GetInteger();

    if ( Valid_Time(hours, min, sec) == TRUE )
    {
        printf("Valid: yes");
    }
    else
    {
        printf("Valid: no");
    }
return 0;
}

bool Valid_Time(int hours, int min, int sec)
{
    if (hours >= 0 && hours <= 23)
        if (min >= 0 && min <= 59)
            if (sec >= 0 && sec <= 59)
                    return TRUE;

    return FALSE;
}

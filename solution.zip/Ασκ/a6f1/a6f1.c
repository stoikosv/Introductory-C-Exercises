 /*File: a6f1.c
  *This program calculates
  *the extra money an employ
  *should have at the end of the year
  */

  #include <stdio.h>
  #include "simpio.h"
  #include "genlib.h"

  int main() {

    int days;
    long payment    ;
    double bonus,gift;

    printf("Dwse tis hmeres ergasias tou etous: ");
    days = GetInteger();
    printf("dwse thn hmerhsia amoibh: ");
    payment = GetLong();
    printf("Dwse to pososto dwrou: ");
    gift = GetReal();

    bonus = days * payment * gift;

    printf("To dwro einai: %g\n" , bonus);

    return 0;

}

#include <stdio.h>
#include "genlib.h"
#include "simpio.h"

#define N 100

void inputArray(int n, int a[]);
void inputNumbers(int *A, int *B);
void performCaclulations(int n, int a[], int *A, int *B, int *pl1, int *pl2, int *pl3);
void ShowResults(int n, int a[], int A, int B, int pl1, int pl2, int pl3);

int main()
{
    int n, a[N], A, B, pl1, pl2, pl3;
    printf("Give n: ");
    n = GetInteger();
    inputArray(n,a);
    inputNumbers(&A, &B);
    performCaclulations(n, a, A, B, &pl1, &pl2, &pl3);
    ShowResults(n, a, A, B, pl1, pl2, pl3);
    return 0;
}

void inputArray(int n, int a[])
{
    int i;
    for (i=0;i<n;i++)
    {
        printf("Give element [%d]: ", i);
        a[i] = GetInteger();
    }
}

void inputNumbers(int *A, int *B)
{

    printf("Give A: ");
    *A = GetInteger();
    printf("Give B: ");
    *B = GetInteger();
    printf("\n");
}

void performCaclulations(int n, int a[], int *A, int *B,int *pl1, int *pl2, int *pl3)
{
    int i;
     *pl1 = 0;
     *pl2 = 0;
     *pl3 = 0;
    for (i=0;i<n;i++)
    {
        if (a[i] <= A)
            (*pl1)++;
        else if(a[i] >= B)
            (*pl2)++;
        if (a[i] > A && a[i] < B)
            (*pl3)++;
    }
}

void ShowResults(int n, int a[], int A, int B, int pl1, int pl2, int pl3)
{
    int i;
    printf("----The numbers of the array-----\n");
    for (i=0;i<n;i++)
        printf("%d ", a[i]);
    printf("\n");
    printf("A = %d\n", A);
    printf("B = %d\n", B);
    printf("Numbers smaller or equal to A: %d\n", pl1);
    printf("Numbers bigger or equal to B: %d\n", pl2);
    printf("Numbers bigger than A and smaller than B: %d\n", pl3);
}

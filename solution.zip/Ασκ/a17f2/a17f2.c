#include <stdio.h>
#include "genlib.h"
#include "simpio.h"

int main()
{
    int theseis, epibates;
    double pos;

    printf("Dose theseis: ");
    theseis = GetInteger();
    printf("Dose epibates: ");
    epibates = GetInteger();
    pos = ((double)epibates / (double)theseis) * 100;
    if (pos >= 50)
    {
        printf("Kerdos");
    }
    else if (pos <= 30)
    {
        printf("Zimia");
    }
    else
    {
        printf("Kerdos");
    }

    return 0;
}

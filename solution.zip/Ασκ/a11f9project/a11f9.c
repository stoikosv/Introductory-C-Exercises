#include <stdio.h>
#include "genlib.h"
#include "simpio.h"
#include <string.h>

#define N 100

typedef struct
{
    int arithmos;
    char name[28];
    int pontoi;
}paikthsT;

void readFromFile(FILE* infile, paikthsT paikths[], int* allplayers, int* players10, int* allpoints);

void writeToFile(FILE* outfile, paikthsT paikths[], int allplayers, int players10, int allpoints);

int main()
{
    FILE* infile;
    FILE* outfile;
    char inputfilename[100], outputfilename[100];
    paikthsT paikths[N];
    int allplayers, players10, allpoints;

    while(TRUE)
    {
        printf("Dwste to onoma gia to arxeio eisodou: ");
        gets(inputfilename);
        infile = fopen(inputfilename, "r");
        if (infile != NULL)
            break;
        printf("Cannot open file %s. Try again. \n",inputfilename);
    }

    readFromFile(infile, paikths, &allplayers, &players10, &allpoints);

    printf("Dwste to onoma gia to arxeio exodou: ");
    gets(outputfilename);
    outfile = fopen(outputfilename, "w");
    writeToFile(outfile, paikths, allplayers, players10, allpoints);

    fclose(infile);
    fclose (outfile);

return 0;
}


void readFromFile(FILE* infile, paikthsT paikths[], int* allplayers, int* players10, int* allpoints)
{
    int nscan, noumero, points;
    char name[28], termch;

    int line = *allplayers = *players10 = *allpoints = 0;

    do
    {
        nscan = fscanf(infile, "%d, %28[^,], %d%c", &noumero, name, &points, &termch);

        if (nscan != EOF)
           {
               line++;

        if (nscan != 4 || termch != '\n') {
            printf("Error in line %d. Program termination\n", line);
            exit(1);}


    paikths[*allplayers].arithmos = noumero;
            strcpy(paikths[*allplayers].name, name);
            paikths[*allplayers].pontoi = points;

            ++*allplayers;
            *allpoints += points;
            if(points > 10) ++*players10;

            }
    }while (nscan != EOF);
}


void writeToFile(FILE* outfile, paikthsT paikths[], int allplayers, int players10, int allpoints)
{
    int i;

    fprintf(outfile, "%-28s%11s\n", "ONOMATEPWNYMO", "PONTOI");

    for (i=0;i<39;i++)
        fputc('-', outfile);
    fputc('\n', outfile);

    for (i=0;i<allplayers;i++)
        fprintf(outfile, "%-28s%11d\n", paikths[i].name, paikths[i].pontoi);

    for (i=0;i<39;i++)
        fputc('-', outfile);
    fputc('\n', outfile);

    fprintf(outfile, "%-28s%11d\n", "SYNOLO PONTWN", allpoints);
    fprintf(outfile, "%-28s%11d\n", "SYNOLO PAIKTVN >= 10", players10);
}

#include <stdio.h>
#include "genlib.h"
#include "simpio.h"

long encode(long arx_kwd);
bool check(long tel_kwd);

int main()
{
    long lower, upper;

    printf("Lower Limit: ");
    lower = GetLong();
    printf("Upper Limit: ");
    upper = GetLong();

    for (lower; lower <= upper; lower++)
    {
        printf("Code: %ld Encoding: %ld",lower, encode(lower));
        if (check(encode(lower)) == TRUE)
            printf(" isValid:yes\n");
        else
            printf(" isValid:no\n");
    }
    return 0;
}


long encode(long arx_kwd)
{
    long tel_kwd,temp;

    temp = (98 - (arx_kwd * 100) % 97) % 97;
    tel_kwd = arx_kwd * 100 + temp;

    return tel_kwd;
}

bool check(long tel_kwd)
{
    if (tel_kwd % 97 == 1)
        return TRUE;
    else
        return FALSE;
}

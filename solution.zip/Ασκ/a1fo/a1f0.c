/*File name: a1f0.c
 Author: Evangelos Stoikos
 Date: 3 Oct 2022
 This program adds two numbers
 */

 #include <stdio.h>
 #include "simpio.h"
 #include "genlib.h"

 main () {
   int n1,n2, total ;
   printf("This program adds two numbers.\n");
printf("1st number? ");
n1 = GetInteger();
printf("2nd number? ");
   n2 = GetInteger();
   total = n1 + n2;
   printf("the sum is %d\n", total);
 }

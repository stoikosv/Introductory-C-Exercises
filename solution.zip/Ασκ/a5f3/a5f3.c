#include <stdio.h>
#include "genlib.h"
#include "simpio.h"

int main()
{
     int kwd, fyllo, baros, ypsos, hlikia, N, i, max, mkwdikos, mfyllo, mbaros, mypsos, mhlikia;

     printf("Dwse to plhthos: ");
     N = GetInteger();

     max = -1;

     for(i=1; i<=N; i++)
     {
         printf("Dwse ton kwdiko: ");
         kwd = GetInteger();
         printf("Dwse to fyllo: ");
         fyllo = GetInteger();
         printf("Dwse to baros: ");
         baros = GetInteger();
         printf("Dwse to ypsos: ");
         ypsos = GetInteger();
         printf("Dwse thn hlikia: ");
         hlikia = GetInteger();

         if (fyllo ==0 && ypsos > max)
         {
             max = ypsos;
             mkwdikos = kwd;
             mfyllo = fyllo;
             mbaros = baros;
             mypsos = ypsos;
             mhlikia = hlikia;
         }
     }

         printf("%d %d %d %d %d", mkwdikos, mfyllo, mbaros, mypsos, mhlikia);

         return 0;
}

#include <stdio.h>
#include "genlib.h"
#include "simpio.h"

int main()
{
    int kwdikos, pagio;
    long par_endeixh, pro_endeixh, katanalwsh, axia;
    double fpa, syn_poso;

    printf("Dwse ton kwdiko kathgorias timologiou: ");
    kwdikos = GetInteger();
    printf("Dwse thn parousa endeixh toy metrhth: ");
    par_endeixh = GetLong();
    printf("Dwse tn prohgoumenh endeixh toy metrhth: ");
    pro_endeixh = GetLong();

    katanalwsh = par_endeixh - pro_endeixh;
    printf("Katanalwsh reumatos se monades: %d\n ", katanalwsh);

    if (katanalwsh <= 200)
    {
        axia = katanalwsh * 12;
    }
    else if (katanalwsh <= 500)
    {
        axia = 200 * 12 + (katanalwsh - 200) * 15;
    }
    else if (katanalwsh <= 1500)
    {
        axia = 200 * 12 + 300 * 15 + (katanalwsh - 500) * 20;
    }
    else if (katanalwsh <= 10000)
    {
        axia = 200 * 12 +300 * 15 + 1000 * 20 +(katanalwsh - 1500) * 30;
    }
    printf("Axia reumatos (cent): %d \n", axia);

    switch (kwdikos)
    {
    case 1: case 2:
        pagio = 20;
        break;
    case 3:
        pagio =100;
        break;
    }
    printf("Pagio (eyro): %d \n", pagio);
    fpa = ((double)axia / 100.0 + (double)pagio) * 0.18;
    printf("FPA (euro): %g \n", fpa);
    syn_poso = (double)axia / 100.0 + (double)pagio + fpa;
    printf("Synoliko poso plhrwmhs (euro): %g \n", syn_poso);

    return 0;
    }

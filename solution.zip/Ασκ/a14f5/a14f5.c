#include <stdio.h>
#include "genlib.h"
#include "simpio.h"

#define N 50

int read();
void read_data(int n, long a[n]);
void print_data(int n, long a[n]);
int FindMaxPos(int n, long a[n], int index[n]);

int main()
{
    int n, pl, i;
    long a[N];
    int index[N];


    n = read();

    read_data(n, a);

    print_data(n, a);

    pl = FindMaxPos(n, a, index);
    printf("Plithos maximum %d\n", pl);
    printf("Positions of maximum ");
    for (i=pl+1;i<n;i++)
    {
        if (index[i] != 0)
            printf("%d ",index[i]);
    }

    return 0;
}


int read()
{
    int n;
    printf("Dwse to plhthos twn stoixeiwn: ");
    n = GetInteger();
    return n;
}


void read_data(int n, long a[n])
{
    int i;
    for (i=0;i<n;i++)
    {
        a[i] = GetLong();
    }
}

void print_data(int n, long a[n])
{
    int i;
    for (i=0;i<n;i++)
    {
        printf("%ld ", a[i]);
    }
    printf("\n");
}


int FindMaxPos(int n, long a[n], int index[n])
{
    int i, max, pl;
    max = a[0];
    index[0] = 0;
    for (i=1;i<n;i++)
    {
        index[i] = 0;
        if (a[i] > max)
        {
            max = a[i];
            pl =0;
        }
        if (max == a[i])
        {
            pl++;
            index[i] = i;
        }
    }
    printf("maximum %d\n", max);
    return pl;
}

#include <stdio.h>
#include "genlib.h"
#include "simpio.h"

int fibonacci(int n);

int main()
{
    int n, i;

    printf("Dwse to n: ");
    n = GetInteger();

    for (i = 1; i <= n; i++)
    {
        printf("%5d\n", fibonacci(i));
    }
return 0;
}


int fibonacci(int n)
{
    int t1, t2, next_term, i;

    t1 = 0;
    t2 = 1;

    for (i =1; i<= n; i++)
    {
        if (i <= 2)
            next_term = i -1;
        else
        {
            next_term = t1 + t2;
            t1 = t2;
            t2 = next_term;
        }
    }
    return next_term;
}




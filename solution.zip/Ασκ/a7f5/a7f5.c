#include <stdio.h>
#include "genlib.h"
#include "simpio.h"

#define M1 50
#define N1 50
#define M2 50
#define N2 50

int main()
{
    int i,j,m1, n1, m2, n2,k;
    long A[M1][N1], B[M2][N2], c[M2][N2], d[m2][n2], temp;

    printf("Dwse to plhthos twn gramwn m1: ");
    m1 = GetInteger();
    printf("Dwse to plhthos twn sthlwn n1: ");
    n1 = GetInteger();
    printf("Dwse to plhthos twn gramwn m2: ");
    m2 = GetInteger();
    printf("Dwse to plhthos twn sthlwn n2: ");
    n2 = GetInteger();

    for (i=0; i<m1; i++)
    {
        for (j=0; j<n1; j++)
        {
            A[i][j] = GetLong();
        }
    }
     for (i=0; i<m2; i++)
    {
        for (j=0; j<n2; j++)
        {
            B[i][j] = GetLong();
        }
    }

    if (m1!= m2 || n1!=n2)
    {
        printf("ERROR +\n");
        printf("ERROR -\n");
    }
    else
    {
        for (i=0; i<m1; i++)
        {
            for (j=0; j<n1; j++)
            {
                c[i][j] = A[i][j] + B[i][j];
            }
        }
        printf("%ld \n",c[i][j]);

        for (i=0; i<m1; i++)
        {
            for (j=0; j<n2; j++)
            {
                d[i][j] = A[i][j] - B[i][j];
            }
        }
        printf("%ld \n", d[i][j]);
    }

    if (n1 != m2)
        printf("ERROR *\n");
    else
    {
        for (k=0; k<m1; k++)
        {
            for (i=0; i< n2; i++)
            {
                temp = 0;
                for (j=0; j<n1; j++)
                {
                    temp = temp + A[k][j]  * B[j][i];
                }
                printf("%ld ", temp);
            }
            printf("\n");
        }
    }
return 0;
}

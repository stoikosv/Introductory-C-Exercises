#include <stdio.h>
#include <string.h>
#include "genlib.h"
#include "simpio.h"

#define MAX_PASSENGERS 100

int main()
{
    char theseis[MAX_PASSENGERS][20], name[20];
    int i, j=1, num_passengers = 0;


    while (1)
    {
        printf("Passenger in seat %d :", j);
        scanf("%s", name);
        j++;

        if (strcmp(name, "----") == 0)
        {
            break;
        }


        int name_exists = 0;
        for (i = 0; i < num_passengers; i++)
        {
            if (strcmp(name, theseis[i]) == 0)
            {
                name_exists = 1;
                break;
            }
        }

        if (name_exists)
        {
            printf("Passenger %s already exists.\n", name);
            j--;
        }
        else
        {
            strcpy(theseis[num_passengers], name);
            num_passengers++;
        }
    }

    printf("\n");
    printf("Passenger List\n--------------\n");
    j=1;
    for (i = 0; i < num_passengers; i++)
    {
        printf("In seat %d:%s\n",j, theseis[i]);
        j++;
    }

  return 0;
}

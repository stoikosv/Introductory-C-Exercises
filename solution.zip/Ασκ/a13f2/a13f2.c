#include<stdio.h>
#include "genlib.h"
#include "stdio.h"

int main()
{
    int kafedes, resta, e2, e1, l50, l20, l10;

    printf("Dose kafedes: ");
    kafedes = GetInteger();
    if ((kafedes * 70) > 500)
    {
        printf("Sfalma");
    }
    else
    {
        resta = 500 - kafedes * 70;
        e2 = resta / 200;
        e1 = resta % 200 / 100;
        l50 = resta % 200 % 100 / 50;
        l20 = resta % 200 % 100 % 50 /20;
        l10 = resta % 200 % 100 % 50 % 20 / 10;
        printf("Kermata 2E: %d \n", e2);
        printf("Kermata 1E: %d \n", e1);
        printf("Kermata 50L: %d \n", l50);
        printf("Kermata 20L: %d \n", l20);
        printf("Kermata 10L: %d \n", l10);
    }
    return 0;
}

#include <stdio.h>
#include "genlib.h"
#include "simpio.h"
#include <string.h>

#define N 20

typedef struct
{
    int kwdikos;
    char epwnymo[16];
    long poso;
    int perioxh;
}eggrafesT;

void get_data(int pl_pwlhtwn, eggrafesT pwlhseis[]);
long calc_totals(int pl_pwlhtwn, eggrafesT pwlhseis[], long totals[]);
void print_data(int pl_pwlhtwn, eggrafesT pwlhseis[], long totals[], long synolo);

int main()
{
    eggrafesT pwlhseis[N];
    int pl_pwlhtwn,i;
    long totals[5], synolo=0;

    for (i=0; i<5; i++)
    {
        totals[i] == 0;
    }

    printf("Dwse to plhthos twn pwlhtwn? ");
    pl_pwlhtwn = GetInteger();

    get_data(pl_pwlhtwn, pwlhseis);
    synolo = calc_totals(pl_pwlhtwn, pwlhseis, totals);
    print_data(pl_pwlhtwn, pwlhseis, totals, synolo);
   return 0;
}


void get_data(int pl_pwlhtwn, eggrafesT pwlhseis[])
{
    int i;

    for (i=0; i<pl_pwlhtwn; i++)
    {
        printf("Kwdikos? ");
        pwlhseis[i].kwdikos = GetInteger();

        printf("Onomatepwnymo? ");
        gets(pwlhseis[i].epwnymo);

        printf("Poso pwlhsewn? ");
        pwlhseis[i].poso = GetLong();

        printf("Kwdikos (1= Thes/niki, 2= Athens, 3= Volos, 4= Hrakleio)? ");
        pwlhseis[i].perioxh = GetInteger();
    }
}

long calc_totals(int pl_pwlhtwn, eggrafesT pwlhseis[], long totals[])
{
    int i;
    long synolo;

    for (i=0; i<pl_pwlhtwn; i++)
    {
        if(pwlhseis[i].perioxh == 1)
        {
            totals[0] += pwlhseis[i].poso;
        }
        if(pwlhseis[i].perioxh == 2)
        {
            totals[1] += pwlhseis[i].poso;
        }
        if(pwlhseis[i].perioxh == 3)
        {
            totals[2] += pwlhseis[i].poso;
        }
        if(pwlhseis[i].perioxh == 4)
        {
            totals[3] += pwlhseis[i].poso;
        }
    }
    synolo = totals[0]+totals[1]+totals[2]+totals[3];
    return synolo;
}


void print_data(int pl_pwlhtwn, eggrafesT pwlhseis[], long totals[], long synolo)
{
    int i;

    printf("    PERIOXH SYN.PWLHSEWN\n");
    for(i=0; i<24; i++)
        printf("-");
    printf("\n");

       printf("  Thes/niki %12ld\n", totals[0]);
       printf("     Athens %12ld\n", totals[1]);
       printf("      Volos %12ld\n", totals[2]);
       printf("   Hrakleio %12ld\n", totals[3]);

    for(i=0; i<24; i++)
        printf("-");
    printf("\n");

    printf("    SYNOLO: %12ld", synolo);
}

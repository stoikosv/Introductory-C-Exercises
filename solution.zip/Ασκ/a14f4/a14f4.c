#include <stdio.h>
#include "genlib.h"
#include "simpio.h"

int maximum(int n1, int n2);
int gr(int n1, int n2, int n3);

int main()
{
    int a, b, c;
    double y;

    printf("Dwse a: ");
    a = GetInteger();
    printf("Dwse b: ");
    b = GetInteger();
    printf("Dwse c: ");
    c = GetInteger();

    y = ( 2 * maximum(a,b) + 3 * gr(a,b,c) ) / 4;

    printf("y = %.2f\n", y);

    return 0;
}


int maximum(int n1, int n2)
{
    int result;

    if (n1 > n2)
        result = n1;
    else if (n2 > n1)
        result = n2;

    return result;
}

int gr(int n1, int n2, int n3)
{
    int result;

    if (n1 > n2 && n1 > n3)
        result = n1;
    else if (n2 > n1 && n2 > n3)
        result = n2;
    else if (n3 > n1 && n3 > n2)
        result = n3;

    return result;
}

#include <stdio.h>
#include "genlib.h"
#include "simpio.h"

int main()
{
    long foros, eisodima, syn_foros;

    printf("Dwse to eisodhma: ");
    eisodima = GetLong();
    printf("%ld Euro\n", eisodima);

    if (eisodima >= 1 && eisodima <= 10000)
        {
            printf("0 Euro\n");
            foros = 0;
            printf("%ld Euro\n", foros);
            syn_foros = 0;
        }
    else if (eisodima <= 39000)
        {
            printf("0 Euro\n");
            foros = (eisodima - 10000) * 0.18;
            printf("%ld Euro\n", foros);
            syn_foros = 0 + foros;
        }
    else if (eisodima <= 49000)
        {
            printf("5220 Euro\n");
            foros = (eisodima - 39000) * 0.21;
            printf("%ld Euro\n", foros);
            syn_foros = 5220 + foros;
        }
    else if (eisodima <= 59000)
        {
            printf("7320 Euro\n");
            foros = (eisodima - 49000) * 0.24;
            printf("%ld Euro\n", foros);
            syn_foros = 7320 + foros;
        }
    else if (eisodima <= 85000)
        {
            printf("9720 Euro\n");
            foros = (eisodima - 59000) * 0.28;
            printf("%ld Euro\n", foros);
            syn_foros = 9720 + foros;
        }
    else if (eisodima <= 100000)
        {
            printf("17000 Euro\n");
            foros = (eisodima - 85000) * 0.33;
            printf("%ld Euro\n", foros);
            syn_foros = 17000 + foros;
        }
    else if (eisodima <= 120000)
        {
            printf("21950 Euro\n");
            foros = (eisodima - 100000) * 0.38;
            printf("%ld Euro\n", foros);
            syn_foros = 21950 + foros;
        }
    else if (eisodima <= 150000)
        {
            printf("29550 Euro\n");
            foros = (eisodima - 120000) * 0.43;
            printf("%ld Euro\n", foros);
            syn_foros = 29950 + foros;
        }
    else if (eisodima <= 170000)
       {
            printf("42450 Euro\n");
            foros = (eisodima - 150000) * 0.49;
            printf("%ld Euro\n", foros);
            syn_foros = 42450 + foros;
       }
    else
        {
            printf("52250 Euro\n");
            foros = (eisodima - 170000) * 0.50;
            printf("%ld Euro\n", foros);
            syn_foros = 52250 + foros;
        }

    printf("%ld Euro\n", syn_foros);

return 0;
}

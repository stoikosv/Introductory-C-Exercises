#include <stdio.h>
#include "genlib.h"
#include "simpio.h"

int main()
{
    long purchase_amount;
    double rate, discount, amount;

    printf("Dwse thn axia tou emporeumatos: ");
    purchase_amount = GetLong();
    printf("Dwse to pososto ekptwshs: ");
    rate = GetReal();

    discount = rate * (double)purchase_amount;
    amount = (double)purchase_amount - discount;

    printf("To poso plhrwmhs einai: %g\n", amount);
    printf("H ekptwsh einai: %g\n", discount);

    return 0;
}

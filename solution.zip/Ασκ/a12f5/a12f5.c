#include <stdio.h>
#include "genlib.h"
#include "simpio.h"

#define m 30
#define n 10

int main()
{
    int i,j,M,N;
    double A[m][n], sum, mo[m], B[m][n], MO[m];

    printf("Dwse ton arithmo twn mathitwn: ");
    M = GetInteger();
    printf("Dwse ton arithmo twn thematwn: ");
    N = GetInteger();

    for (i=1; i<=M; i++)
    {
        for (j=1; j<=N; j++)
        {
            printf("Dwse th bathmologia tou %dou thematos tou %dou mathiti: ",j, i);
            A[i][j] = GetReal();
        }
    }
    for (i=1; i<=M; i++)
    {
        sum = 0;
        for (j=1; j<=N; j++)
        {
            sum += A[i][j];
        }
        mo[i] = sum / N;
    }
    for (i=1; i<=M; i++)
    {
        for (j=1; j<=N; j++)
        {
            B[i][j] = A[i][j] / 5;
        }
        MO[i] = mo[i] / 5;
    }
    for (i=1; i<=M; i++)
    {

        printf("%6.1lf%6.1lf%6.1lf\n", A[i][1],A[i][2],mo[i]);
        printf("%6.1lf%6.1lf%6.1lf\n", B[i][1],B[i][2],MO[i]);

    }

return 0;
}

#include <stdio.h>
#include "genlib.h"
#include "simpio.h"

int main()
{
    int poso, plhthos, syn_poso, max, min;

    syn_poso = 0;
    plhthos = 0;
    max = -1;
    min = 100001;

    while (syn_poso < 100000)
    {
        plhthos ++;
        printf("Dose poso: ");
        poso = GetInteger();
        syn_poso += poso;
        if (poso > max)
        {
            max = poso;
        }
        if (poso < min)
        {
            min = poso;
        }
    }

    printf("Plithos atomon: %d\n", plhthos);
    printf("Synoliko poso: %d\n", syn_poso);
    printf("Megalitero poso: %d  Mikrotero poso: %d", max, min);

    return 0;
}

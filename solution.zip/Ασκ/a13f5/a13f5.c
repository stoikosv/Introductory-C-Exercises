#include <stdio.h>
#include <stdlib.h>
#include "genlib.h"
#include "simpio.h"

#define R 10
#define C 10

void populate_data(int r, int c, int A[r][c]);
void print_array(int r, int c, int A[r][c]);
void change_array(int r, int c, int A[r][c]);

int main()
{
    int r, c, i, j;
    int A[R][C];

    printf("Dwse ton arithmo twn grammwn: ");
    r = GetInteger();
    printf("Dwse ton arithmo twn sthlwn: ");
    c = GetInteger();

    populate_data(r, c, A);

    printf("ARXIKOS PINAKAS\n");
    print_array(r ,c ,A);

    change_array(r, c, A);

    printf("ALLAGMENOS PINAKAS\n");
    print_array(r, c, A);

    return 0;
}

void populate_data(int r, int c, int A[r][c])
{
    int i, j;

    for (i=0; i<r; i++)
    {
        for (j=0; j<c; j++)
        {
         A[i][j] = rand() % 100;
        }
    }
}

void print_array(int r, int c, int A[r][c])
{
    int i, j;

    for (i=0; i<r; i++)
    {
        for (j=0; j<c; j++)
        {
            printf("%d ", A[i][j]);
        }
        printf("\n");
    }
}

void change_array(int r, int c, int A[r][c])
{
    int i, j, max, spot;

    for (i=0; i<r; i++)
    {
        max = A[i][0];
        for (j=0; j<c; j++)
        {
            if (A[i][j] > max)
            {
                max = A[i][j];
                spot = j;
            }
        }
        for (j=0; j<spot; j++)
        {
            A[i][j] = max;
        }
    }
}

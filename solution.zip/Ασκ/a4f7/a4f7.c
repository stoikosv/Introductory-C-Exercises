#include <stdio.h>
#include "genlib.h"
#include "simpio.h"
#include <string.h>
#include <ctype.h>
#include <stdlib.h>

int main()
{
    int x, size;

    printf("Dwse akeraio: ");
    x = GetInteger();
    printf("Dwse mhkos: ");
    size = GetInteger();

    char str[size+1];
    sprintf(str, "%d", x);
    int len = strlen(str);
    if (len < size)
    {
        int i;
        for (i = 0; i < size-len; i++)
        {
            printf("0");
        }
    }

    printf("%s\n", str);

    return 0;
}
